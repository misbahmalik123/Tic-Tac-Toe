// script.js
const cells = document.querySelectorAll('.cell');
let currentPlayer = 'X';
let gameBoard = Array(9).fill(null);

cells.forEach(cell => {
    cell.addEventListener('click', handleClick);
});

function handleClick(event) {
    const cell = event.target;
    const index = cell.dataset.index;

    if (gameBoard[index] !== null) {
        return;
    }

    cell.textContent = currentPlayer;
    gameBoard[index] = currentPlayer;

    if (checkWin()) {
        alert(`${currentPlayer} wins!`);
        resetGame();
    } else if (gameBoard.every(cell => cell !== null)) {
        alert('It\'s a draw!');
        resetGame();
    } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    }
}

function checkWin() {
    const winningCombinations = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [2, 4, 6]
    ];

    return winningCombinations.some(combination => {
        const [a, b, c] = combination;
        return gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c];
    });
}

function resetGame() {
    gameBoard.fill(null);
    cells.forEach(cell => (cell.textContent = ''));
    currentPlayer = 'X';
}
